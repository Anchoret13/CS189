for i=1:30
    y(i)=x(i+1)
end