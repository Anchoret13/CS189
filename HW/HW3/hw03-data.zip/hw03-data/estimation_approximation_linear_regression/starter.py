import numpy as np
import matplotlib.pyplot as plt

# assign problem parameters


# generate data
# np.random might be useful

# fit data with different models
# np.polyfit and np.polyval might be useful


# plotting figures
# sample code

# plt.figure()
# plt.subplot(121)
# plt.semilogy(np.arange(1, deg+1),error[:,-1])
# plt.xlabel('degree of polynomial')
# plt.ylabel('log of error')
# plt.subplot(122)
# plt.semilogy(np.arange(n_s, n_s+step), error[-1,:])
# plt.xlabel('number of samples')
# plt.ylabel('log of error')
# plt.show()
